import React from "react";
import { render } from "react-dom";
import { createStore, bindActionCreators } from "redux";
import { Provider, connect } from "react-redux";

const counter = (state, action) => {
  switch (action.type) {
    case "+":
      return state + 1;
    case "-":
      return state - 1;
    default:
      return state;
  }
};

const store = createStore(counter, 0);

class App extends React.Component {
  state = {
    counter: null
  };

  componentDidMount() {
    store.subscribe(() => {
      this.setState({
        counter: store.getState()
      });
    });
  }

  render() {
    return (
      <div>
        <h1>Ahoji</h1>
        <h2>{this.state.counter}</h2>
        <button onClick={() => store.dispatch({ type: "+" })}>Add +1</button>
        <button onClick={() => store.dispatch({ type: "-" })}>Add -1</button>
      </div>
    );
  }
}

class App2 extends React.Component {
  render() {
    const { dispatch } = this.props;

    return (
      <div>
        <h1>Ahoj</h1>
        <h2>{this.props.counter}</h2>
        <button onClick={() => dispatch({ type: "+" })}>Add +1</button>
        <button onClick={() => dispatch({ type: "-" })}>Add -1</button>
      </div>
    );
  }
}

class App3 extends React.Component {
  render() {
    const { addOne, addMinusOne } = this.props;

    return (
      <div>
        <h1>Ahoj 3</h1>
        <h2>{this.props.counter}</h2>
        <button onClick={() => addOne()}>Add +1</button>
        <button onClick={() => addMinusOne()}>Add -1</button>
      </div>
    );
  }
}

function mapDispatchToProps(dispatch) {
  return bindActionCreators(
    {
      addOne: () => ({ type: "+" }),
      addMinusOne: () => ({ type: "-" })
    },
    dispatch
  );
}

function mapStateToProps(state) {
  return {
    counter: state
  };
}

const EnhancedApp = connect(mapStateToProps, mapDispatchToProps)(App3);

render(
  <Provider store={store}>
    <EnhancedApp />
  </Provider>,
  document.getElementById("root")
);
